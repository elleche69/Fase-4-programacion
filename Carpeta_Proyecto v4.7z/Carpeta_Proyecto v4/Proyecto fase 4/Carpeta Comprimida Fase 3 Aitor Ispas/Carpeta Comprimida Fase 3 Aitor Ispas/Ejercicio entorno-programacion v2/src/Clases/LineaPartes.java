/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author 1GBD09
 */
public class LineaPartes {
    
    private int id;
    
    private String hora_salida;
    
    private String hora_llegada;
    
    private Vehiculo vehiculo;
    
    private Albaran albaran;
    
    private Partes parte;

    public LineaPartes(int id, String hora_salida, String hora_llegada, Vehiculo vehiculo, Albaran albaran, Partes parte) {
        this.id = id;
        this.hora_salida = hora_salida;
        this.hora_llegada = hora_llegada;
        this.vehiculo = vehiculo;
        this.albaran = albaran;
        this.parte = parte;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHora_salida() {
        return hora_salida;
    }

    public void setHora_salida(String hora_salida) {
        this.hora_salida = hora_salida;
    }

    public String getHora_llegada() {
        return hora_llegada;
    }

    public void setHora_llegada(String hora_llegada) {
        this.hora_llegada = hora_llegada;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public Albaran getAlbaran() {
        return albaran;
    }

    public void setAlbaran(Albaran albaran) {
        this.albaran = albaran;
    }

    public Partes getParte() {
        return parte;
    }

    public void setParte(Partes parte) {
        this.parte = parte;
    }
    
    
    
    
    
    
    
    
    
}
