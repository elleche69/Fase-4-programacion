
package Excepciones;


public class Campo_obligatorio_sin_patron_vacio extends Exception{
    
}
