


package Excepciones;


public class Sueldo_Incorrecto extends Exception{

    public Sueldo_Incorrecto() {
    }
    
    
    
}
