/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author 1GBD09
 */
public class VentanaLineas extends javax.swing.JFrame {

   
    public VentanaLineas() {
        initComponents();
        
        
    }
    
      
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        num_albaran = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setText("Numero Albaran");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        num_albaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                num_albaranActionPerformed(evt);
            }
        });

        jLabel2.setText("Tiempo Ida");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24" }));

        jLabel3.setText(":");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24" }));

        jLabel4.setText(":");

        jLabel5.setText("Tiempo vuelta");

        jLabel6.setText("Vehiculo utilizado");

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });

        jButton1.setText("Añadir nueva linea");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Salir");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 803, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jButton1)
                            .addGap(628, 628, 628)
                            .addComponent(jButton2))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addGap(18, 18, 18)
                            .addComponent(num_albaran, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(33, 33, 33)
                            .addComponent(jLabel6)
                            .addGap(18, 18, 18)
                            .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(num_albaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 330, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void num_albaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_num_albaranActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_num_albaranActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
                
        Recuperar_Datos();        
        Añadir_nueva_linea();    
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        n  = this.jLabel1.getY();
    }//GEN-LAST:event_formWindowOpened

    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox5ActionPerformed

    private void Añadir_nueva_linea(){
        n = n + 30;  
        Añadir_Label1();
        Añadir_CampoTexto1();
        Añadir_Label2();
        Añadir_ComboBox1();
        Añadir_Label3();
        Añadir_Combo2();
        Añadir_Label4();
        Añadir_Combo3();
        Añadir_Label5();
        Añadir_Combo4();
        Añadir_Label6();
        Añadir_Combo5();
    }    
        
    
    
    
    private void Añadir_Label1(){             
        this.add(label = new JLabel()).setBounds(jLabel1.getX(), n , jLabel1.getWidth(), jLabel1.getHeight());
        label.setText(jLabel1.getText());    
    }
    
    private void Añadir_CampoTexto1(){                    
        this.add(text = new JTextField()).setBounds(num_albaran.getX(), n, num_albaran.getWidth(), num_albaran.getHeight());
    }    
    
    private void Añadir_Label2(){
        this.add(label2 = new JLabel()).setBounds(jLabel2.getX(), n, jLabel2.getWidth(), jLabel2.getHeight());
        label2.setText(jLabel2.getText());
    }    
        
    private void Añadir_ComboBox1(){
        this.add(combo1 = new JComboBox()).setBounds(jComboBox1.getX(), n, jComboBox1.getWidth(), jComboBox1.getHeight());
        int nx = 0;
        
        while (nx < jComboBox1.getItemCount()){        
            combo1.addItem(jComboBox1.getItemAt(nx));
            nx = nx + 1;        
        }
    }    
    
    private void Añadir_Label3(){
        this.add(label3 = new JLabel()).setBounds(jLabel3.getX(), n, jLabel3.getWidth(), jLabel3.getHeight());
        label3.setText(jLabel3.getText());
    
    }
    
    private void Añadir_Combo2(){
        this.add(combo2 = new JComboBox()).setBounds(jComboBox2.getX(), n, jComboBox2.getWidth(), jComboBox2.getHeight());
        int nx = 0;
        
        while (nx < jComboBox2.getItemCount()){        
            combo2.addItem(jComboBox2.getItemAt(nx));
            nx = nx + 1;        
        }
    }
    
    private void Añadir_Label4(){
        this.add(label4 = new JLabel()).setBounds(jLabel5.getX(), n,jLabel5.getWidth(), jLabel5.getHeight());
        label4.setText(jLabel5.getText());
    }
    
    private void Añadir_Combo3(){
    
        this.add(combo3 = new JComboBox()).setBounds(jComboBox4.getX(), n, jComboBox4.getWidth(), jComboBox4.getHeight());
        int nx = 0;
        
        while (nx < jComboBox4.getItemCount()){        
            combo3.addItem(jComboBox4.getItemAt(nx));
            nx = nx + 1;        
        }
        
    }
    
    private void Añadir_Label5(){
        this.add(label5 = new JLabel()).setBounds(jLabel4.getX(), n, jLabel4.getWidth(), jLabel4.getHeight());
        label5.setText(jLabel4.getText());
    
    }
    
    private void Añadir_Combo4(){
    
        this.add(combo4 = new JComboBox()).setBounds(jComboBox3.getX(), n, jComboBox3.getWidth(), jComboBox3.getHeight());
        int nx = 0;
        
        while (nx < jComboBox3.getItemCount()){        
            combo4.addItem(jComboBox3.getItemAt(nx));
            nx = nx + 1;        
        }
    }
    
    private void Añadir_Label6(){
        this.add(label6 = new JLabel()).setBounds(jLabel6.getX(), n, jLabel6.getWidth(), jLabel6.getHeight());
        label6.setText(jLabel6.getText());
    
    }
    
    private void Añadir_Combo5(){
        this.add(combo5 = new JComboBox()).setBounds(jComboBox5.getX(),n, jComboBox5.getWidth(), jComboBox5.getHeight());
        int nx = 0; 
        
        while (nx < jComboBox5.getItemCount()){        
            combo5.addItem(jComboBox5.getItemAt(nx));
            nx = nx + 1;        
        }
    
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaLineas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaLineas().setVisible(true);
            }
        });
    }
    
    
    private void Recuperar_Datos(){
    
        data = new ArrayList();
        
        if (n  == this.jLabel1.getY()){
            data.add(num_albaran.getText());
            data.add(jComboBox1.getSelectedItem().toString());
            data.add(jComboBox2.getSelectedItem().toString());
            data.add(jComboBox4.getSelectedItem().toString());
            data.add(jComboBox3.getSelectedItem().toString());
            data.add(jComboBox5.getSelectedItem().toString());
        }
    
        else{
        
            data.add(text.getText());
            data.add(combo1.getSelectedItem().toString());
            data.add(combo2.getSelectedItem().toString());
            data.add(combo3.getSelectedItem().toString());
            data.add(combo4.getSelectedItem().toString());
            data.add(combo5.getSelectedItem().toString());
        }
        
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.Recuperar_Datos_Lineas(data);
        
        
    }
    
    
    
    private JComboBox<String> combo1;
    private JComboBox<String> combo2;
    private JComboBox<String> combo3;    
    private JComboBox<String> combo4;
    private JComboBox<String> combo5;
    private JLabel label;
    private JLabel label2;  
    private JLabel label3; 
    private JLabel label4;
    private JLabel label5;
    private JLabel label6;
    private JTextField text;
    private int n;
    private ArrayList<String> data;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField num_albaran;
    // End of variables declaration//GEN-END:variables
}
